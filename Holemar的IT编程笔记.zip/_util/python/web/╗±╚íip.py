﻿#-*- coding: utf-8 -*-

import re, urllib2
from subprocess import Popen, PIPE
import socket

print "本机的私网IP地址为：" + re.search('\d+\.\d+\.\d+\.\d+',Popen('ipconfig', stdout=PIPE).stdout.read()).group(0)
#print "本机的公网IP地址为：" + re.search('\d+\.\d+\.\d+\.\d+',urllib2.urlopen("http://www.whereismyip.com").read()).group(0)

# 缓存ip,没必要每次都去获取
local_ip = None
def getip():
    '''
        返回公网ip,取不到时返回None
    '''
    global local_ip
    if local_ip: return local_ip

    ip_list = [
        "http://www.ip138.com/ip2city.asp",
        "http://www.whereismyip.com/",
        "http://www.bliao.com/ip.phtml"
    ]
    for ip_url in ip_list:
        try:
            local_ip = visit_ip(ip_url)
            return local_ip
        except:
            pass
    return None

def visit_ip(url):
    '''
        访问网页，以获取网页上显示的ip内容
    '''
    opener = urllib2.urlopen(url)
    if url == opener.geturl():
        str = opener.read()
    return re.search('\d+\.\d+\.\d+\.\d+',str).group(0)


#print "本机的公网IP地址为：" + getip()


#直接获取本地IP(局域网)
'''
    getsocketname:获得本机的信息（IP和port）
    getpeername：获得远程机器的信息（IP和port）
    fileno：每一个socket对应一个fd，使用此方法可以获得fd，为一个整数
'''
print socket.gethostbyname(socket.gethostname())
print socket.gethostbyname_ex(socket.gethostname())


######################################################
#linux下:
import socket
import fcntl
import struct
def get_ip_address(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915, # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])
#get_ip_address('lo')环回地址
#get_ip_address('eth0')主机ip地址

﻿
# python2
###### get ###########################
import urllib2
import cookielib

def download(url):
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookielib.CookieJar()))
    opener.addheaders = [('User-agent', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322)')]
    f = opener.open(url)
    s = f.read()
    f.close()
    return s

s = download("http://www.baidu.com/")
print(s)


# python2
###### post ###########################
import urllib2, urllib

def download(url, param = None):
    if param:
        f = urllib2.urlopen(url = url, data = urllib.urlencode(param))
    else:
        f = urllib2.urlopen(url = url)
    return f.read()

s = download('http://www.ideawu.net/', {'name' : 'www', 'password' : '123456'})
print(s)






# python3
#################################
import urllib.request, urllib.error
import http.cookiejar

def download(url):
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    opener.addheaders = [('User-agent', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322)')]
    f = opener.open(url)
    s = f.read()
    f.close()
    return s

s = download("http://www.baidu.com/")
print(s)


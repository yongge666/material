#coding=utf-8
import random

DATE_FORMAT = "%Y-%m-%d"
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"

def random_num_code(size=15):
    cs = []
    for i in range(size):
        cs.append(str(random.randint(0, 9)))            
    return ''.join(cs)

def time_to_s(value):
    if value:
        return value.strftime(TIME_FORMAT)
    return ''

def date_to_s(value):
    if value:
        return value.strftime(DATE_FORMAT)
    return ''    

def reg_code_to_pk_code(reg_code):
    from django.utils.encoding import force_unicode    
    import cPickle as pickle
    import re, os
    
    rs = r'^(\d{10}|\d{13}|\d{15}|\d{8}-\d{2,3}|L\d{14})$'
    rs = re.search(rs, reg_code)
    if rs:
        return reg_code.upper()

    path = os.path.join( os.path.dirname(__file__), 'reg_code_name.map')
    f = file(path, 'rb')
    map = pickle.load(f)
    map_province = map['province']
    map_city = map['city']
    f.close()
    pat = re.compile(r'\D{6,8}\d{6}\D')

    reg_code = force_unicode(reg_code)
    if pat.search(reg_code):
        if len(reg_code) == 13:
            p = reg_code[2].encode('utf-8')
            m = map_province.get(p, None)
            if m:
                return '%s-%s' % (m[0], reg_code[-7:-1])
        else:
            c = reg_code[3].encode('utf-8')
            m = map_city.get(c, None)
            if m:
                return '%s-%s' % (m[0], reg_code[-7:-1])
    
    return None   
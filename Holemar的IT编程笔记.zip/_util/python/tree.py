#!/usr/bin/env python
#coding=utf-8
import re

#为dict添加obj.property的访问方式
class DictObject(dict):
    def __new__(cls, *args, **kwargs):
        self = dict.__new__(cls, *args, **kwargs)
        self.__dict__ = self
        return self

# sorted_objs为按code排序过的节点列表，必需有code和rank属性
def get_tree(sorted_objs, code_attr='code', rank_attr='rank', children_attr='children'):
    sorted_objs = map(lambda o: DictObject(o) if isinstance(o, dict) else o, sorted_objs)
        
    #树的根节点
    tree = []
    #保存树当前所在分支的各级节点
    level_root = []
    #保存当前分支的各级节点的兄弟节点编码和子节点编码正则，比level_root长度多1,因为最后一个节点保存了子节点编码正则
    level_rex = []

    for index, obj in enumerate(sorted_objs):
        #if obj['code'] == '02020001':
        #    import pprint
        #    raw_input('tree')
        #    pprint.pprint(tree)
        #    raw_input('level_root')
        #    pprint.pprint(level_root)
        #    raw_input('level_rex')
        #    pprint.pprint(level_rex)
            
#        obj['children'] = []
        setattr(obj, children_attr, [])
#        parent_code = obj['code']
        parent_code = getattr(obj, code_attr)
        code = parent_code
        while True:
            code_next, s = code[:-2], code[-2:]
            if s != '00':
                break
            else:
                code = code_next
                
        brother_mask = code_next + '\d{2}' + '0'*(8-len(code_next)-2)

        if getattr(obj, rank_attr) == 4:
            child_mask = '\d{2}000000'           
        elif getattr(obj, rank_attr) == 3:
            child_mask = parent_code[:2] + '\d{2}0000'
        elif getattr(obj, rank_attr) == 2:
            child_mask = parent_code[:4] + '\d{2}00'
        elif getattr(obj, rank_attr) == 1:
            child_mask = parent_code[:6] + '\d{2}'
        elif getattr(obj, rank_attr) == 0:
            child_mask = '999999'
            
        if not tree:
            tree.append(obj)
            level_root.append(obj)
            level_rex.append(brother_mask)
            level_rex.append(child_mask)
        else:
            sub_index = 0
            is_mached = False
            for re_index, rex in enumerate(level_rex):
                if re.compile(rex).match(getattr(obj, code_attr)):
                    is_mached = True
                    if re_index > 0:
                        getattr(level_root[re_index-1], children_attr).append(obj)
                    #若当前code不能匹配前一个的子节点code，则前一个为叶子节点，删除该节点的children属性
                    if re_index != len(level_rex)-1:
                        delattr(level_root[len(level_root)-1], children_attr)
                    sub_index = re_index
            #若当前code不能匹配当前树路径的所有code，则前一个为叶子节点，删除该节点的children属性
            if not is_mached:
                delattr(level_root[len(level_root)-1], children_attr)

            if sub_index == 0:
                tree.append(obj)
            
            index_region = range(sub_index,len(level_rex))
            index_region.reverse()
            for i in index_region:
                try:
                    del(level_rex[i])
                    del(level_root[i])
                except:
                    pass
    
            level_rex.append(brother_mask)
            level_rex.append(child_mask)
            level_root.append(obj)
        #删除最后一个node的children属性
        if index == len(sorted_objs)-1:
            delattr(obj, children_attr)
    return tree

#干掉所有没有申证编号的分类，以后再引申其他通用功能
def remove_no_sz(tree):
    if isinstance(tree, list):
        tree = {'children':tree}
    
    children = tree.get('children', [])
    children_len = len(children)
    for i, sub_tree in enumerate(children[-1::-1]):
        #干掉没儿子没申证的节点
        if sub_tree.get('children', None) == None:
            if sub_tree.get('sz_code','') == '':
                #print 'del %s' % sub_tree['code']
                del children[children_len-i-1]
        else:
            #把他儿子都处理一遍之后，如果他变成没儿子没申证，干掉
            remove_no_sz(sub_tree)
            #print 'sub_tree',sub_tree
            if not sub_tree['children']:
                if sub_tree.get('sz_code','') == '':
                    #print 'del %s' % sub_tree['code']
                    del children[children_len-i-1]
                else:
                    #print 'del children %s' % sub_tree['code']
                    del sub_tree['children']

    #print 'root',tree
    #print 'over!'

if __name__ == '__main__':
    #class Node(object):
    #    def __init__(self, code, rank):
    #        self.code = code
    #        self.rank = rank
    #    def __str__(self):
    #        return self.code
        
    import pprint
    import datetime
    #objs = eval(file('/home/gd/Desktop/default1.log', 'r').read())
    objs = [{'code':'01040000','rank':2, 'sz_code':''},{'code':'01040100','rank':1, 'sz_code':'aa'},{'code':'01040200','rank':1, 'sz_code':'bb'},{'code':'01040300','rank':1, 'sz_code':''},{'code':'02010000','rank':1, 'sz_code':''},{'code':'02010001', 'rank':0, 'sz_code':''}]
    tree = get_tree(objs)
    remove_no_sz(tree)
    pprint.pprint(tree)

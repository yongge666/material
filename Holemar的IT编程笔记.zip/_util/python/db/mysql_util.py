﻿#!python
# -*- coding:utf-8 -*-

import logging

from DBUtils.PooledDB import PooledDB # 需安装第三方插件 DBUtils
import MySQLdb # 需安装第三方插件 MySQLdb
import MySQLdb.cursors

# 线程池
dbpool = PooledDB(MySQLdb, 2, 5, 0, 50, **{'host':"localhost", 'port':3306, 'user':"root", 'passwd':"root", 'db':"test", 'charset':'utf8', 'cursorclass':MySQLdb.cursors.DictCursor})


def db_select(sql, fetchone=None):
    '''执行查询SQL语句
       @param {string} sql: 要查询的SQL语句
    '''
    try:
        conn = None
        cur = None
        logging.debug(sql)
        conn = dbpool.connection()
        cur = conn.cursor()
        cur.execute(sql)
        if not fetchone:
            return cur.fetchone()
        else:
            return cur.fetchall()
    except:
        logging.error(u"查询失败:%s" % sql, exc_info=True)
        return
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

def db_modify(sql, param=None):
    '''执行SQL语句'''
    try:
        conn = None
        cur = None
        logging.info("%s, %s" % (sql, param))
        conn = dbpool.connection()
        cur = conn.cursor()
        if not param:
            row = cur.execute(sql)
        else:
            row = cur.execute(sql, param)
        conn.commit()
        return row

    except MySQLdb.IntegrityError:
        logging.error(u"主键冲突:", exc_info=True)
        #主键冲突,重复insert,忽略错误
        return 1
    except:
        logging.error(u"更新失败:%s" % sql, exc_info=True)
        conn.rollback()
        return
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

def db_modifys(sql_list):
    '''执行多条SQL语句，并且是一个原子事件(任何一条SQL执行失败，或者返回结果为0，都会全体回滚)
       @param {list<tuple<string,dict>>} sql_list: 形式为 [(sql1, param1),(sql2, param2),(sql3, param3),...]
    '''
    try:
        conn = None
        cur = None
        conn = dbpool.connection()
        cur = conn.cursor()
        row = 0
        for sql, param in sql_list:
            logging.info("%s, %s" % (sql, param))

            try:
                if not param:
                    this_row = cur.execute(sql)
                else:
                    this_row = cur.execute(sql, param)
            except MySQLdb.IntegrityError:
                logging.error(u"主键冲突:", exc_info=True)
                #主键冲突,重复insert,忽略错误
                this_row = 1

            if this_row <= 0:
                raise u'其中一条更新失败'
            row += this_row
        conn.commit()
        return row

    except:
        logging.error(u"更新失败:%s" % sql, exc_info=True)
        conn.rollback()
        return
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()


def query_data(table, flag=2, condition=None):
    sql = "SELECT * FROM t_%s " % table
    if condition:
        condition_sql = format_sql(' AND ', condition)
        sql += " WHERE %s" % (condition_sql)
    rows = db_select(sql, flag)
    return rows

def add_data(table, params):
    column = ",".join(params.keys())
    # 防止值里面含单引号的情况,一个单引号替换成两个即可
    value = ",".join("'%s'" % unicode(x).replace("'","''") for x in params.values())
    sql = "INSERT INTO t_%s (%s) VALUES (%s)" % (table, column, value)
    row = db_modify(sql)
    return row

def add_datas(table_list):
    '''一起插入多个语句,原子操作，其中任意一个操作语句失败都会全体回滚
    @param {list<tuple<string,dict>>} table_list: 形式为 [(table_name1, param1),(table_name2, param2),(table_name3, param3),...]
    @return: 返回总的影响行数
    @example rows = add_datas([('goods_log',{'bid':'333','orderid':"e''ee"}),('product_log',{'bid':'444','orderid':u"哎f'f"})])
    '''
    sql_list =  []
    for table, params in table_list:
        column = ",".join(params.keys())
        # 防止值里面含单引号的情况,一个单引号替换成两个即可
        value = ",".join("'%s'" % unicode(x).replace("'","''") for x in params.values())
        sql = "INSERT INTO t_%s (%s) VALUES (%s)" % (table, column, value)
        sql_list.append((sql, None,))
    row = db_modifys(sql_list)
    return row

def del_data(table, condition=None):
    if not condition:
        return 0
    condition_sql = format_sql(' AND ', condition)
    sql = "DELETE FROM t_%s WHERE %s" % (table, condition_sql)
    row = db_modify(sql)
    return row

def update_data(table, params=None, condition=None):
    if not (params and condition):
        return 0
    up_sql = format_sql(' , ', params)
    condition_sql = format_sql(' AND ', condition)
    sql = "UPDATE t_%s SET %s WHERE %s" % (table, up_sql, condition_sql)
    row = db_modify(sql)
    return row


def format_sql(sep, params):
    '''格式化SQL语句'''
    res = []
    for k, v in params.iteritems():
        if isinstance(v, int) or isinstance(v, long) and v < 1000000000:
            pass
        # 字符串需要防止有单引号的情况,一个单引号替换成两个即可
        elif isinstance(v, (str, unicode)):
            v = "'%s'" % (v.replace("'","''"))
        else:
            v = "'%s'" % v
        res.append("%s=%s" % (k, v))
    if len(res) > 1:
        return ("%s" % sep).join(res)
    return res[0]


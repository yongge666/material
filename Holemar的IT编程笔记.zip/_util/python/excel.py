from pyExcelerator import *

def save(file_name, fields, field_ns, datas):
    book = Workbook()
    for name, rows in datas.items():
        sheet = book.add_sheet(name)
        
        ci = 0
        for c in fields:
            sheet.write(0, ci, field_ns[c])
            ci += 1
 
        ri = 1        
        for r in rows:
            ci = 0
            for c in fields:
                sheet.write(ri, ci, r[c])
                ci += 1
            ri += 1
                
    book.save(file_name)    
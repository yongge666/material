#coding=utf-8
import re

def join(split_word=',', arrs=[]):
    arrs = pack_list(arrs)
    return split_word.join(arrs)


def pack_list(arrs=[]):
    return map(to_unicode, arrs)


def pack_dict(**kwargs):
    tmp = []
    for k,v in kwargs.items():
        tmp.append(u'%s=%s' % (to_unicode(k), to_unicode(v)))
    return ','.join(tmp)

def to_str(arg):
    if isinstance(arg, unicode):
        arg = arg.encode('utf-8')
    return str(arg)


def to_unicode(arg):
    if not isinstance(arg, basestring):
        return unicode(arg)

    if not arg:
        return u''

    if not isinstance(arg, unicode):
        try:
            arg = arg.decode('utf-8')
        except:
            try:
                arg = arg.decode('GBK')
            except:
                pass
    return arg


def x_to_unicode(arg):
    if not isinstance(arg, basestring):
        if isinstance(arg, list):
            return join(arrs=arg)
        elif isinstance(arg, dict):
            return pack_dict(**arg)
    return to_unicode(arg)


def _show_tuple(arg):
    tmp = []
    for x in arg:
        tmp.append(_show_data(x))
    if len(tmp) == 1:
        tmp.append('')
    return '(%s)' % ', '.join(tmp)


def _show_list(arg):
    tmp = []
    for x in arg:
        tmp.append(_show_data(x))
    return '[%s]' % ', '.join(tmp)


def _show_dict(kwargs):
    tmp = []
    for k,v in kwargs.items():
        result = dict(k=k, v=v)
        for t in ['k', 'v']:
            result[t] = _show_data(result[t])
        tmp.append('%s: %s' % (result['k'], result['v']))
    return '{%s}' % ', '.join(tmp)


def _show_data(data):
    temp = None
    if isinstance(data, dict):
        temp = _show_dict(data)
    elif isinstance(data, list):
        temp = _show_list(data)
    elif isinstance(data, tuple):
        temp = _show_tuple(data)
    else:
        temp = to_unicode(data)
    if isinstance(data, str):
        temp = "'%s'" % temp
    elif isinstance(data, unicode):
        temp = "u'%s'" % temp
    return temp


def show_data(data, output='utf8'):
    output = output.lower()
    temp = _show_data(data)
    if output == 'unicode':
        return temp
    return temp.encode(output)


def toHtmlCode(sour):
    '''
    转换字符串成 Html 页面上显示的编码
    @param sour 需要转换的字符串
    @return 转换后的字符串
    @example toHtmlCode(" ") 返回: &nbsp;
    '''
    # 以下逐一转换
    sour = sour.replace("&", "&amp;")
    sour = sour.replace("%", "&#37;")
    sour = sour.replace("<", "&lt;")
    sour = sour.replace(">", "&gt;")
    sour = sour.replace("\n", "\n<br/>")
    sour = sour.replace('"', "&quot;")
    sour = sour.replace(" ", "&nbsp;")
    sour = sour.replace("'", "&#39;")
    sour = sour.replace("+", "&#43;")
    return sour


def toTextCode(sour):
    '''
    转换字符串由 Html 页面上显示的编码变回正常编码(以上面的方法对应)
    @param sour 需要转换的字符串
    @return 转换后的字符串
    @example toTextCode("&nbsp;") 返回: " "
    '''
    # 以下逐一转换
    # 先转换百分号
    sour = sour.replace("&#37;", "%")
    # 小于号,有三种写法
    sour = sour.replace("&lt;", "<")
    sour = sour.replace("&LT;", "<")
    sour = sour.replace("&#60;", "<")
    # 大于号,有三种写法
    sour = sour.replace("&gt;", ">")
    sour = sour.replace("&GT;", ">")
    sour = sour.replace("&#62;", ">")
    # 单引号
    sour = sour.replace("&#39;", "'")
    sour = sour.replace("&#43;", "+")
    # 转换换行符号
    sour = re.sub(r'\n?<[Bb][Rr]\s*/?>\n?', '\n', sour)
    # 双引号号,有三种写法
    sour = sour.replace("&quot;", '"')
    sour = sour.replace("&QUOT;", '"')
    sour = sour.replace("&#34;", '"')
    # 空格,只有两种写法, &NBSP; 浏览器不承认
    sour = sour.replace("&nbsp;", " ")
    sour = sour.replace("&#160;", " ")
    # & 符号,最后才转换
    sour = sour.replace("&amp;", "&")
    sour = sour.replace("&AMP;", "&")
    sour = sour.replace("&#38;", "&")
    return sour


def removeHTMLTag(text):
    '''
    清除HTML标签
    @return 清除标签后的内容
    @example removeHTMLTag("<div>haha</div>") 返回: "haha"
    '''
    # 清除注释
    text = text.replace("<!--.*-->", "")
    # 标题换行: </title> ==> 换行符
    text = re.sub(r'</[Tt][Ii][Tt][Ll][Ee]>', '\n', text)
    # 换行符换行: <br/> ==> 换行符
    text = re.sub(r'\n?<[Bb][Rr]\s*/?>\n?', '\n', text)
    # tr换行: </tr> ==> 换行符
    text = re.sub(r'</[Tt][Rr]>', '\n', text)
    # html標籤清除
    text = re.sub(r'<[^>]+>', '', text)
    # 转换字符串由 Html 页面上显示的编码变回正常编码
    text = toTextCode(text)
    return text.strip()


if __name__ == '__main__':
    import sys
    if len(sys.argv) == 1:
        output = 'utf-8'
    elif len(sys.argv) == 2:
        filename, output = sys.argv
    else:
        print 'error: too many argument!'
        exit(1)

    s = '这是一段中文文字'
    print
    print
    print
    print '=' * 80
    print 'output encoding is "%s"' % output
    print 'output 1', '-' * 71
    print repr(show_data(s, output))
    print 'output 2', '-' * 71
    print show_data(s, output)
    print '=' * 80

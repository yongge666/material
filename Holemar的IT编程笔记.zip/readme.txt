
作者:

	冯万里(Holemar)
	QQ:   292598441
	邮箱: daillow@gmail.com
	MSN:  daillo@live.cn
	skype:daillow
	更新日期: 2013-11-4


更多更新资料请访问：

	http://db.tt/ORtPX1Y3
	http://yunpan.cn/QGk3JSmcYVPh4



另外，本人收集的软件也分享出来。

	为了防止病毒感染以及杀毒软件误杀，软件都放压缩包里面并且加密。解压密码统一是:123456
	http://yunpan.cn/QWn7B2LrYx7dB


编程方面的电子书:

	http://yunpan.cn/Q5PAWvyR7m9Lh


使用360云盘的，欢迎加我的云盘群:

	http://qun.yunpan.360.cn/1200392


交流QQ群:26651479

document.writeln('<script type="text/javascript">');
document.writeln('/*wx.9ku.com 悬浮 20:3，创建于2014-7-10*/');
document.writeln('var cpro_id = "u1616436";');
document.writeln('</script>');
document.writeln('<script src="cm.js"/*tpa=http://cpro.baidustatic.com/cpro/ui/cm.js*/ type="text/javascript"></script>');